
#include "game.h"
class Menu{
public:

//add menu attributes here
Menu()
{

//constructors body
}

void display_menu()

{

    Game g; 
//display menu screen here

// add functionality of all the menu options here

//if Start game option is chosen 
    
    g.start_game();



}


};
